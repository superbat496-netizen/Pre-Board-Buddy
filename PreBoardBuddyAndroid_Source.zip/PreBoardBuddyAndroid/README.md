# PreBoard Buddy — Android APK source project

This is a native Android starter project. It is source code, **not a compiled APK yet**.

## Features included
- Home dashboard and counts
- 40-day progress counter, study routine, and saved subject checklist
- Mistake Log: subject, chapter, question, reason, correction, corrected status
- Marks Slot: subject, test name, marks, date, notes, percentages, combined score
- Local persistence using Android SharedPreferences

## Phone-only path to build an APK using GitHub Actions
1. Open GitHub in Chrome and sign in or create an account.
2. Create a new repository named `PreBoardBuddy` and set it to **Private** if you prefer.
3. Upload the contents of this ZIP (the files inside the `PreBoardBuddyAndroid` folder) to the repository root. Ensure `.github/workflows/build-apk.yml` is included. If the GitHub website hides dot-folders during upload, use GitHub's web editor to create `.github/workflows/build-apk.yml` with the contents in this project.
4. Open the repository's **Actions** tab and select **Build PreBoard Buddy APK**. Tap **Run workflow** if it has not run automatically after upload.
5. Wait for the workflow to finish successfully. Open its run page and find **Artifacts** near the bottom. Download `PreBoardBuddy-debug-apk`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then tap the APK to install it. Android may ask you to allow installs from Chrome or Files; only allow it for this APK you built and trust.

## Build from a computer
Open this folder in Android Studio with Android SDK Platform 35 and Java 17, then build `assembleDebug`.

## Data and privacy
Mistake Log and Marks Slot entries are stored locally on the device. They are not uploaded or synced. Uninstalling the app or clearing its data may erase them. This starter does not include a cloud backup.

## Limitations
The app has basic tracking, not a pre-filled chapter-by-chapter 40-day timetable. The APK produced by the workflow is a debug APK for personal testing, not a Play Store release.
