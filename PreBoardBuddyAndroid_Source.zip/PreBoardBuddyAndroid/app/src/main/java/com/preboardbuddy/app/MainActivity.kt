package com.preboardbuddy.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Typeface
import android.text.InputType
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("preboard_buddy_local", MODE_PRIVATE) }
    private lateinit var content: LinearLayout
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun label(s: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(0xFF202938.toInt())
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(2), dp(6), dp(2), dp(6))
    }
    private fun btn(s: String, action: () -> Unit) = Button(this).apply { text = s; setOnClickListener { action() } }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); page("Home") }

    private fun page(which: String) {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)); setBackgroundColor(0xFFF5F7FB.toInt()) }
        root.addView(label("📚 PreBoard Buddy", 25f, true))
        root.addView(label("Class 10 • Your study companion", 14f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Home", "40-Day Plan", "Mistake Log", "Marks Slot").forEach { name ->
            nav.addView(Button(this).apply { text = name; textSize = 9f; setOnClickListener { page(name) } }, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(nav)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(20)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        when (which) { "Home" -> home(); "40-Day Plan" -> plan(); "Mistake Log" -> mistakes(); "Marks Slot" -> marks() }
    }

    private fun home() {
        content.addView(label("Welcome back! 🌟", 22f, true))
        content.addView(label("Your study entries are saved on this phone."))
        content.addView(label("📌 Dashboard", 18f, true))
        content.addView(label("Mistakes logged: ${load("mistakes").length()}\nTest entries: ${load("marks").length()}\nPlan days completed: ${prefs.getInt("completed_days", 0)} / 40"))
        content.addView(btn("＋ Add a mistake") { page("Mistake Log"); addMistake() })
        content.addView(btn("＋ Add test marks") { page("Marks Slot"); addMarks() })
        content.addView(label("Daily routine", 18f, true))
        content.addView(label("1. Revise a topic\n2. Solve questions/PYQs\n3. Record mistakes\n4. Enter test marks\n5. Review old mistakes"))
        content.addView(label("Storage: local to this phone; no cloud sync. Uninstalling or clearing app data may erase entries.", 13f))
    }

    private fun plan() {
        content.addView(label("40-Day Pre-Board Plan 🗓️", 21f, true))
        content.addView(label("Plan window: 11 Oct – 18 Nov 2026\nDaily target: 4 hours • Sundays: lighter revision"))
        val done = prefs.getInt("completed_days", 0)
        content.addView(label("Completed: $done / 40", 18f, true))
        content.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 40; progress = done }, LinearLayout.LayoutParams(-1, dp(12)))
        content.addView(btn("Mark next day complete ✓") { prefs.edit().putInt("completed_days", (prefs.getInt("completed_days", 0) + 1).coerceAtMost(40)).apply(); page("40-Day Plan") })
        content.addView(btn("Reset day counter") { AlertDialog.Builder(this).setMessage("Reset completed-day count?").setNegativeButton("Cancel", null).setPositiveButton("Reset") { _, _ -> prefs.edit().putInt("completed_days", 0).apply(); page("40-Day Plan") }.show() })
        content.addView(label("Daily 4-hour template", 18f, true))
        content.addView(label("• 90 min — main chapter\n• 60 min — second subject\n• 60 min — questions and PYQs\n• 30 min — mistake review\n\nSunday: revise formulas, review mistakes, and plan the week."))
        content.addView(label("Subject checklist", 18f, true))
        listOf("Mathematics", "Science", "Social Science", "English", "Sanskrit Communicative", "Information Technology").forEach { s ->
            val cb = CheckBox(this).apply { text = s; isChecked = prefs.getBoolean("subject_$s", false); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("subject_$s", checked).apply() } }
            content.addView(cb)
        }
        content.addView(label("This starter tracks daily completion and subject checkboxes; a detailed chapter-by-chapter schedule is not built in yet.", 13f))
    }

    private fun mistakes() {
        content.addView(label("Mistake Log 📝", 21f, true))
        content.addView(label("Save errors and review them later."))
        content.addView(btn("＋ Add mistake") { addMistake() })
        val arr = load("mistakes")
        if (arr.length() == 0) content.addView(label("No mistakes yet. Add your first one above."))
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(-1) }
            card.addView(label("${o.optString("subject")} • ${o.optString("chapter")}", 17f, true))
            card.addView(label("Question: ${o.optString("question")}\nWhy: ${o.optString("why")}\nCorrection: ${o.optString("fix")}\nDate: ${o.optString("date")}"))
            card.addView(btn(if (o.optBoolean("corrected")) "✓ Corrected — tap to reopen" else "Mark corrected ✓") { o.put("corrected", !o.optBoolean("corrected")); arr.put(i, o); save("mistakes", arr); page("Mistake Log") })
            card.addView(btn("Delete entry") { AlertDialog.Builder(this).setMessage("Delete this mistake?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> save("mistakes", removeAt(arr, i)); page("Mistake Log") }.show() })
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
    }

    private fun addMistake() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), 0) }
        fun field(h: String): EditText { val e = EditText(this); e.hint = h; form.addView(e); return e }
        val subject = field("Subject"); val chapter = field("Chapter/topic"); val question = field("Question or mistake"); val why = field("Why did I get it wrong?"); val fix = field("Correct method/answer")
        AlertDialog.Builder(this).setTitle("Add to Mistake Log").setView(form).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            val a = load("mistakes"); a.put(JSONObject().apply { put("subject", subject.text.toString().trim().ifBlank { "Unspecified" }); put("chapter", chapter.text.toString().trim().ifBlank { "Unspecified topic" }); put("question", question.text.toString().trim()); put("why", why.text.toString().trim()); put("fix", fix.text.toString().trim()); put("date", today()); put("corrected", false) }); save("mistakes", a); page("Mistake Log")
        }.show()
    }

    private fun marks() {
        content.addView(label("Marks Slot 📊", 21f, true)); content.addView(label("Save test scores and review your results.")); content.addView(btn("＋ Add test marks") { addMarks() })
        val a = load("marks"); if (a.length() == 0) content.addView(label("No marks yet. Add a test above."))
        var scoredSum = 0.0; var totalSum = 0.0
        for (i in a.length() - 1 downTo 0) {
            val o = a.optJSONObject(i) ?: continue; val scored = o.optDouble("scored"); val total = o.optDouble("total"); scoredSum += scored; totalSum += total
            val pct = if (total > 0) scored * 100 / total else 0.0
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8)); setBackgroundColor(-1) }
            card.addView(label("${o.optString("subject")} — ${o.optString("test")}", 17f, true))
            card.addView(label("${fmt(scored)} / ${fmt(total)} • ${String.format(Locale.getDefault(), "%.1f", pct)}%\nDate: ${o.optString("date")}\nNotes: ${o.optString("notes")}"))
            card.addView(btn("Delete test entry") { AlertDialog.Builder(this).setMessage("Delete this marks entry?").setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ -> save("marks", removeAt(a, i)); page("Marks Slot") }.show() })
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        if (totalSum > 0) content.addView(label("Combined score: ${fmt(scoredSum)} / ${fmt(totalSum)} (${String.format(Locale.getDefault(), "%.1f", scoredSum * 100 / totalSum)}%)", 17f, true))
    }

    private fun addMarks() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(4), dp(20), 0) }
        fun field(h: String, numeric: Boolean = false): EditText { val e = EditText(this); e.hint = h; if (numeric) e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL; form.addView(e); return e }
        val subject = field("Subject"); val test = field("Test name (PYQ/mock/unit test)"); val scored = field("Marks obtained", true); val total = field("Total marks", true); val notes = field("Notes (optional)")
        AlertDialog.Builder(this).setTitle("Add test marks").setView(form).setNegativeButton("Cancel", null).setPositiveButton("Save") { _, _ ->
            val s = scored.text.toString().toDoubleOrNull(); val t = total.text.toString().toDoubleOrNull()
            if (s == null || t == null || t <= 0 || s < 0 || s > t) { Toast.makeText(this, "Enter valid marks (obtained must be between 0 and total).", Toast.LENGTH_LONG).show(); return@setPositiveButton }
            val a = load("marks"); a.put(JSONObject().apply { put("subject", subject.text.toString().trim().ifBlank { "Unspecified" }); put("test", test.text.toString().trim().ifBlank { "Untitled test" }); put("scored", s); put("total", t); put("notes", notes.text.toString().trim()); put("date", today()) }); save("marks", a); page("Marks Slot")
        }.show()
    }

    private fun load(k: String) = try { JSONArray(prefs.getString(k, "[]")) } catch (_: Exception) { JSONArray() }
    private fun save(k: String, a: JSONArray) { prefs.edit().putString(k, a.toString()).apply() }
    private fun removeAt(a: JSONArray, index: Int): JSONArray { val b = JSONArray(); for (i in 0 until a.length()) if (i != index) b.put(a.get(i)); return b }
    private fun today() = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())
    private fun fmt(n: Double) = if (n % 1.0 == 0.0) n.toInt().toString() else String.format(Locale.getDefault(), "%.1f", n)
}
